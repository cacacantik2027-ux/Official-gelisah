# 📁 Folder IMG — GELISAH VCS Talent Agency

Folder ini digunakan untuk menyimpan semua aset gambar website GELISAH.

## Struktur yang Disarankan

```
img/
├── README.md              ← File ini
├── bg/
│   └── background.jpg     ← Foto background website (opsional)
└── talents/
    ├── talent-1.jpg       ← Foto talent ke-1
    ├── talent-2.jpg       ← Foto talent ke-2
    └── talent-3.jpg       ← Foto talent ke-3
```

## Cara Pakai

Setelah upload foto ke folder ini di GitHub, gunakan URL berikut di Panel Admin:

**Format URL foto di GitHub:**
```
https://raw.githubusercontent.com/USERNAME/NAMA-REPO/main/img/talents/nama-foto.jpg
```

**Contoh:**
```
https://raw.githubusercontent.com/gelisah123/gelisah/main/img/talents/arlina.jpg
https://raw.githubusercontent.com/gelisah123/gelisah/main/img/bg/background.jpg
```

## Catatan

- Format yang didukung: `.jpg`, `.jpeg`, `.png`, `.webp`, `.gif`
- Ukuran foto talent disarankan: **rasio 3:4** (portrait), minimal 400x533px
- Ukuran foto background disarankan: minimal **1920x1080px**
- Ukuran file maksimal disarankan: **2MB per foto** agar website tetap cepat
